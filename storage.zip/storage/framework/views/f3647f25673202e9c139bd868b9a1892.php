<div class="row justify-content-center">
    <div class="col-md-6">
        <?php echo $__env->make('dashboard.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form id="university-edit-form" action="<?php echo e(route('admin.university.update', $university->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('dashboard.common.fields.text', [
                'label_name' => 'University',
                'id' => 'university',
                'name' => 'university',
                'placeholder' => 'Enter University Name',
                'input_attribute' => [
                    'type' => 'text',
                    'value' => old('university', $university->name),
                ],
                'classes' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="form-group">
                <button type="submit" id="submit-btn" class="btn btn-primary">Update</button>
            </div>
        </form>
        <div class="form-group delete " style="margin-top:1%">
          <?php if($university->campus->count() > 0): ?>
           <p><?php echo e($university->name); ?> is related to antother record(s).</p>
          <?php else: ?>
          <form  id="delete-form" method="POST" action="<?php echo e(route('admin.university.destroy', $university->id)); ?>" >
           <?php echo csrf_field(); ?>
           <?php echo method_field('DELETE'); ?>
             <button type="submit" id="submit-btn-delete" class="btn btn-danger">Delete</button>
            </form>
          <?php endif; ?>
        </div>
    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/university/edit.blade.php ENDPATH**/ ?>