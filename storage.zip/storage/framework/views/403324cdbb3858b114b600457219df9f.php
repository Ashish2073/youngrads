<div class="row justify-content-center">
    <div class="col-md-6">
        <?php echo $__env->make('dashboard.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form id="university-create-form" action="<?php echo e(route('admin.university.store')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('dashboard.common.fields.text', [
                'label_name' => 'University',
                'id' => 'university',
                'name' => 'university',
                'placeholder' => 'Enter University Name',
                'input_attribute' => [
                    'type' => 'text',
                    'value' => old('university'),
                ],
                'classes' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <div class="form-group">
                <button type="submit" id="submit-btn" class="btn btn-primary">Add</button>
            </div>
    </div>
    </form>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/university/create.blade.php ENDPATH**/ ?>