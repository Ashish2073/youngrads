<div class="row justify-content-center">
    <div class="col-md-6">
        <?php echo $__env->make('dashboard.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form id="document-create-form" action="<?php echo e(route('admin.document-type.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('dashboard.common.fields.text', [
                'label_name' => 'Title',
                'id' => 'title',
                'name' => 'title',
                'placeholder' => 'Enter Title',
                'input_attribute' => [
                    'type' => 'text',
                    'value' => old('title'),
                ],
                'classes' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <div class="form-group d-none">
                <label for="document_limit">Document Limit</label>
                <select class='form-control select <?php $__errorArgs = ['document_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>' name="document_limit" data-live-search="true" id="document_limit  ">
                     <option value="">--Select Document--</option>
                     <option value="1" selected>1</option>
                    
                </select>
                <?php $__errorArgs = ['document_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group d-none">
              <label>Document Required</label>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" name="document_required" value="1">Yes
                </label>
              </div>
              <div class="form-check-inline">
                <label class="form-check-label">
                  <input type="radio" class="form-check-input" name="document_required" value="0" checked>No
                </label>
              </div>
            </div>

            <div class="form-group">
                <button type="submit" id="submit-btn" class="btn btn-primary">Add</button>
            </div>
    </div>
    </form>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/document_type/create.blade.php ENDPATH**/ ?>