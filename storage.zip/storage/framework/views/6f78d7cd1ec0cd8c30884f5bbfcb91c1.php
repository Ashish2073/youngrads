<div class="row justify-content-center">
  <div class="col-md-6">
      <?php echo $__env->make('dashboard.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <form id="document-edit-form" action="<?php echo e(route('admin.document-type.update', $documentType->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <?php echo $__env->make('dashboard.common.fields.text', [
              'label_name' => 'Title',
              'id' => 'title',
              'name' => 'title',
              'placeholder' => 'Enter Title',
              'input_attribute' => [
                  'type' => 'text',
                  'value' => old('title', $documentType->title),
              ],
              'classes' => '',
          ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="form-group d-none">
              <label for="document_limit">Document Limit</label>
              <select class='form-control select <?php $__errorArgs = ['document_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>' name="document_limit" data-live-search="true" id="document_limit">
                   <option value="">--Select Document--</option>
                   <option value="1">1</option>
                  
              </select>
              <?php $__errorArgs = ['document_limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger"><?php echo e($message); ?></p>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="form-group d-none">
            <label>Document Required</label>
            <div class="form-check-inline">
              <label class="form-check-label">
              <input type="radio" class="form-check-input" name="document_required[]" value="1" <?php if($documentType->is_required == 1): ?> checked  <?php endif; ?> >Yes
              </label>
            </div>
            <div class="form-check-inline">
              <label class="form-check-label">
                <input type="radio" class="form-check-input" name="document_required[]" value="0" <?php if($documentType->is_required == 0): ?> checked  <?php endif; ?> >No
              </label>
            </div>
          </div>

          <div class="form-group">
              <button type="submit" id="submit-btn" class="btn btn-primary">Update</button>
          </div>
        </form>
        <?php if($documentType->hasUserDocuments()): ?>
            <p><?php echo e(config('setting.delete_notice')); ?></p>
        <?php else: ?>
          <div class="form-group delete " >
              <form  id="delete-form" method="POST" action="<?php echo e(route('admin.document-type.destroy', $documentType->id)); ?>" >
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
              <button type="submit" id="submit-btn-delete" class="btn btn-danger">Delete</button>
              </form>
          </div>
        <?php endif; ?>
  </div>
</div>
</div>

<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/document_type/edit.blade.php ENDPATH**/ ?>