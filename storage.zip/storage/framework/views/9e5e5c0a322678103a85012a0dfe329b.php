<?php $__env->startSection('title', 'Shortlisted Programs'); ?>

<?php $__env->startSection('vendor-style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section id="basic-datatable">
  <div class="row">
      <div class="col-12">
          <div class="card">
              
              <div class="card-content">
                  <div class="card-body card-dashboard">
                      <div class="table-responsive">
                          <table id="shortlist-table" class="table w-100 zero-configuration">
                              <thead>
                                <tr>
                                  <th>University Name</th>
                                    <th>Campus Name</th>
                                    <th>Program Name</th>
                                    <th>Action</th>
                                    <th>Application</th>
                                 </tr>
                              </thead>
                          </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
    <!-- Page js files -->
    <script>
      var dataTable;
       $(document).ready(function(){

        dataTable = $("#shortlist-table").DataTable({
                "processing": true,
                "serverSide": true,
                ajax: {
                    url: "<?php echo e(route('shortlist-programs')); ?>",
                    data: function (d) {

                    }
                },
                columns: [
                  {    name: 'university',
                        data: 'university'
                    },
                   {
                     name: 'campus',
                     data: 'campus'
                   },
                   
                    {
                      name:'program',
                      data:'program'
                    },
                    {
                      name: 'action',
                      data: 'action'
                    },
                    {
                      data:'check_apply'
                    }
                ],
                responsive: false,

                drawCallback: function(setting, data) {

                },

                aLengthMenu: [[10, 15, 20], [10, 15, 20]],

                bInfo: false,
                pageLength: 10,
                initComplete: function (settings, json) {
                    $(".dt-buttons .btn").removeClass("btn-secondary");
                    $(".table-img").each(function() {
                        $(this).parent().addClass('product-img');
                    });
                }
            });
            // submitLoader("#first"); submitReset('#first', 'Next');
            $(document).on('click','.remove', function(){
                let that = $(this);
                 if(confirm('Are you sure ?')){
                    $.ajax({
                      url:"<?php echo e(route('shortlist-programs-remove')); ?>",
                      type: 'POST',
                      data: {
                          _token: "<?php echo e(csrf_token()); ?>",
                          id : $(this).data('id')
                      },
                      beforeSend: function(){
                        // shortlist-programs
                        that.attr('disabled', true).prepend("<i class='fa fa-spinner fa-spin'></i> ");
                      },
                      success: function(data){
                            setAlert(data);
                            dataTable.draw('page');
                          that.removeAttr('disabled').html('');
                      }
                  });

                 }

            });


           //apply now
            $(document).on('click','.apply',function(){
                 id = $(this).data('id')
                 $('.dynamic-title').text('Apply Now');

                  $.ajax({
                      url: "<?php echo e(url('apply-application')); ?>"+"/"+ id,
                      beforeSend: function(){
                        $('.dynamic-apply').html("Loading"); 
                      },
                      success: function(data){
                        $('.dynamic-apply').html(data);
                      }
                  })
            });


       });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/user_shortlist_program/index.blade.php ENDPATH**/ ?>