<div class="row">
  <div class="col-12">
    <div class="table-responsive">
     <table id="shortlist-table" class="table table-hover w-100 zero-configuration">
        <thead>
            <tr>
              <th>University</th>
              <th>Campus</th>
              <th>Program</th>
              <th>Detail</th>
            </tr>
        </thead>
        <tbody>
           <?php $__empty_1 = true; $__currentLoopData = $shortlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shortlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <tr>
                 <td><?php echo e($shortlist->university); ?></td>
                 <td><?php echo e($shortlist->campus); ?></td>
                 <td><?php echo e($shortlist->program); ?></td>
                 <td>
                   <a href="<?php echo e(route('program-details', $shortlist->campus_program_id)); ?>" target="_blank">View Program</a>
                 </td>
               </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              
           <?php endif; ?>
        </tbody>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/students/shortlist.blade.php ENDPATH**/ ?>