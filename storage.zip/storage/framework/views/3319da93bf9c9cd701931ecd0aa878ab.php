<?php $__env->startSection('title', 'Update Campus Program'); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <?php echo $__env->make('dashboard.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <form class='form form-vertical' id="campus-program-edit-form"
                action="<?php echo e(route('admin.campus-program.update', $campusProgram->id)); ?>" method="post">
                <div class="row">
                    <div class="col-md-6 col-12">
                        <h4>Campus Program Information</h4>
                        <hr>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="university">University</label>
                            <select class='form-control select <?php $__errorArgs = ['university'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>'
                                name="university" id="university" data-live-search="true">
                                <option value="">--Select University --</option>
                                <?php $__currentLoopData = config('universties'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unversity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option
                                        <?php echo e($unversity->id == old('university', $campusProgram->university_id) ? 'selected' : ''); ?>

                                        value=<?php echo e($unversity->id); ?>><?php echo e($unversity->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['university'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="campus">Campus</label>
                            <select required class='form-control select <?php $__errorArgs = ['campus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>'
                                name="campus" id="campus" data-live-search="true"
                                data-value="<?php echo e(old('campus', $campusProgram->campus_id)); ?>">
                                <?php $__currentLoopData = config('campuses'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($campus->id == old('campus', $campusProgram->campus_id)); ?>

                                        value=<?php echo e($campus->id); ?>><?php echo e($campus->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['campus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="program">Program</label>
                            <select required class='form-control program <?php $__errorArgs = ['program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>'
                                name="program" id="program" data-live-search="true" value="<?php echo e(old('program')); ?>">
                                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option data-duration="<?php echo e($program->duration); ?>"
                                        <?php echo e($program->id == old('program', $campusProgram->program_id) ? 'selected' : ''); ?>

                                        value="<?php echo e($program->id); ?>"><?php echo e($program->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <?php $__errorArgs = ['program'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-4 px-0">
                            <label for="campus_program_duration">Duration</label>
                            <input name="campus_program_duration" id="campus_program_duration" type="number"
                                value="<?php echo e(old('campus_program_duration', $campusProgram->campus_program_duration ?? 0)); ?>"
                                class="form-control <?php $__errorArgs = ['campus_program_duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <?php $__errorArgs = ['campus_program_duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="intake">Intakes</label>
                            <select required class='form-control select <?php $__errorArgs = ['intakes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>'
                                name="intakes[]" id="intake" data-live-search="true" multiple>
                                <?php $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(in_array($intake->id, old('intakes', $intakeIds)) ? 'selected' : ''); ?>

                                        value=<?php echo e($intake->id); ?>><?php echo e($intake->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['intakes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="entery-requirement">Entry Requirement</label>
                            
                            <textarea name="entry_requirement" id="entery-requirement" cols="5" rows="5"
                                class="form-control <?php $__errorArgs = ['entry_requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('entry_requirement', $campusProgram->entry_requirment)); ?></textarea>
                            <?php $__errorArgs = ['entry_requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



                    </div>
                    <div class="col-md-6 col-12">
                        <div class="row">
                            <div class="col">
                                <h4>Program Fees</h4>
                                <hr>
                                <?php
                                    $i = 0;
                                    $j = 0;
                                ?>
                                <?php $__currentLoopData = $feeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feetype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-group mb-0">
                                        <label><?php echo e($feetype->name); ?></label>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-md-8 col-12">
                                            <input min="0" max="9999999"
                                                value="<?php echo e(old("fees.{$i}.price", $campusProgramFees[$feetype->id]['fee_price'])); ?>"
                                                type="text" class="form-control"
                                                placeholder="Add <?php echo e($feetype->name); ?> Fee"
                                                name="fees[<?php echo e($i); ?>][price]">
                                        </div>
                                        <div class="col-md-4 col-12 mt-md-0 mt-50">
                                            <input value="<?php echo e($feetype->id); ?>" type="hidden"
                                                name="fees[<?php echo e($i); ?>][id]">
                                            <select class="select w-100 " name="fees[<?php echo e($i); ?>][currency]">
                                                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    <option
                                                        <?php echo e($selected = $currency->id == old("fees.{$i}.currency", $campusProgramFees[$feetype->id]['fee_currency']) ? 'selected' : ''); ?>

                                                        value="<?php echo e($currency->id); ?>"><?php echo e($currency->code); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php $i++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col">
                                <h4>Test Scores</h4>
                                <hr>
                                <div class="row">
                                    <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group col-6">
                                            <label><?php echo e($test->test_name); ?></label>
                                            <input min="0" max="10" type="text" class="form-control"
                                                name="test[<?php echo e($j); ?>][score]"
                                                value="<?php echo e(old("test.$j.score", $campusProgramTest[$test->id]['score'])); ?>" />
                                            <input type="hidden" name="test[<?php echo e($j); ?>][type]"
                                                value="<?php echo e($test->id); ?>" />
                                            <div class="vs-checkbox-con vs-checkbox-primary mt-1">
                                                <input type="checkbox" value="1"
                                                    name="test[<?php echo e($j); ?>][show]"
                                                    <?php echo e(old("test.$j.show", $campusProgramTest[$test->id]['show_in_front']) == 1 ? 'checked' : ''); ?> />
                                                <span class="vs-checkbox">
                                                    <span class="vs-checkbox--check">
                                                        <i class="vs-icon feather icon-check"></i>
                                                    </span>
                                                </span>
                                                <span class="">Show</span>
                                            </div>
                                        </div>

                                        <?php $j++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">

                        <div class="form-group">
                            <button type="submit" id="submit-btn" class="btn btn-primary">Update</button>
                        </div>
                    </div>
                </div>
            </form>
            <?php if($campusProgram->userApplication->count() > 0): ?>
                <div class="col-md-12">
                    <p><?php echo e(config('setting.delete_notice')); ?></p>
                </div>
            <?php else: ?>
                <div class="form-group delete" style="margin-top:1%">
                    <form id="delete-form" method="POST"
                        action="<?php echo e(route('admin.campus-program.destroy', $campusProgram->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" id="submit-btn-delete" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script>
        $(document).ready(function() {

            $(".select").select2();

            $('.program').select2({
                placeholder: 'Program',
                multiple: false,
                // ajax: {
                //     url: route('select-programs'),
                //     dataType: 'json',
                //     type: 'POST',
                //     data: function(params) {
                //         return {
                //             name: params.term
                //         }
                //     },
                //     processResults: function(data) {
                //         return {
                //             results: data
                //         }
                //     }
                // }
            });

            $(".program").change(function() {
                let duration = $(".program").select2().find(":selected").data("duration");
                $("#campus_program_duration").val(duration);
            });

            validateForm($('#campus-program-create-form, #campus-program-edit-form'), {
                rules: {
                    universtiy: {
                        required: true
                    },

                    intakes: {
                        required: true
                    },
                    price: {
                        required: true
                    },
                    entry_requirement: {
                        required: true
                    }
                },
                messages: {}
            });

            $('#university').change(function() {
                id = $(this).val();
                updateCampuses(id);
            });
            updateCampuses($('#university').find("option:selected").val());

            submitForm($("#delete-form"), {
                beforeSubmit: function() {
                    if (!confirm('Are you sure you want to delete')) return false;
                    submitLoader("#submit-btn-delete");
                },
                success: function(data) {
                    setAlert(data);
                    if (data.success) {
                        window.location = "<?php echo e(route('admin.campus-programs')); ?>";
                    }
                },
                complete: function() {
                    submitReset("#submit-btn-delete");
                },
                error: function(data) {
                    toast("error", "Something went wrong.", "Error");
                }
            });

        });

        function updateCampuses(id) {
            getContent({
                url: "<?php echo e(url('admin/get-campus')); ?>" + "/" + id,
                success: function(data) {
                    option = '';
                    let val = $("#campus").attr('data-value');
                    let selected = "";
                    data.forEach(campus => {
                        if (val == campus.id) {
                            selected = "selected";
                        }
                        option +=
                            `<option ${selected} value=${campus.id}>${campus.name}</option>`;
                        selected = "";
                    });

                    $('#campus').find('option').remove();
                    $('#campus').append(option);
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/campus_program/edit.blade.php ENDPATH**/ ?>