<div class="row justify-content-center">
    <div class="col-md-6">

        <form id="study-edit-form" action="<?php echo e(route('admin.study.update', $study->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <?php echo $__env->make('dashboard.common.fields.text', [
            'label_name' => 'Name',
            'id' => 'name',
            'name' => 'name',
            'placeholder' => 'Enter Page Name',
            'input_attribute' => [
            'type' => 'text',
            'value' => old('name', $study->name),
            ],
            'classes' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           

            <?php if($study->parent_id != 0): ?>
            <div class="form-group">
                <label for="parent_id">Parent</label>
                <select class="select2 form-control" name="parent_id" id="parent_id">
                    <option value="0">Parent</option>
                    <?php $__currentLoopData = config('study_areas'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $study_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($study_area->id == old('parent_id', $study->parent_id) ? 'selected' : ''); ?>

                            value="<?php echo e($study_area->id); ?>"><?php echo e(Str::limit($study_area->name, 40, '...')); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo errMsg($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php endif; ?>

            <div class="form-group">
                <button type="submit" id="submit-btn" class="btn btn-primary">Update</button>
            </div>
        </form>
        <?php if($study->hasChild()): ?>
            <p><?php echo e(config('setting.delete_notice')); ?></p>
       <?php else: ?>
           <div class="form-group delete" style="margin-top:1%">
            <form id="delete-form" method="POST" action="<?php echo e(route('admin.study.destroy', $study->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" id="submit-btn-delete" class="btn btn-danger">Delete</button>
            </form>
           </div>
       <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/study_area/edit.blade.php ENDPATH**/ ?>