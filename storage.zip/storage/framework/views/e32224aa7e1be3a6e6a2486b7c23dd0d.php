<div class="row justify-content-center">
    <div class="col-md-6 col-12">
        <?php echo $__env->make('dashboard.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form id="program-create-form" action="<?php echo e(route('admin.program.store')); ?>" method="post"
              enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('dashboard.common.fields.text', [
                'label_name' => 'Program',
                'id' => 'name',
                'name' => 'name',
                'placeholder' => 'Enter Program Name',
                'input_attribute' => [
                    'type' => 'text',
                    'value' => old('name'),
                ],
                'classes' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <?php echo $__env->make('dashboard.common.fields.text', [
                'label_name' => 'Duration',
                'id' => 'duration',
                'name' => 'duration',
                'placeholder' => 'Enter Program Duration',
                'input_attribute' => [
                    'type' => 'text',
                    'value' => old('duration'),
                ],
                'classes' => '',
                'help_text' => 'Enter duration in months e.g 12'
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            

            

            <div class="form-group">
                <label for="program_level_id">Program Level</label>
                <select class="form-control select <?php $__errorArgs = ['program_level_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="program_level_id" id="program_level_id" data-live-search="true">
                    <option value="">----Program Level----</option>
                    <?php $__currentLoopData = $programLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programLevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($programLevel->id); ?>><?php echo e($programLevel->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['program_level_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="study_area_id">Study Area</label>
                <select class="form-control select <?php $__errorArgs = ['study_area_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="study_area_id" data-live-search="true">
                    <option value="">----Select Study Area----</option>
                    <?php $__currentLoopData = config('study_areas'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studyArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(old('study_area_id') == $studyArea->id ? "selected" : ""); ?> value=<?php echo e($studyArea->id); ?>><?php echo e($studyArea->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['study_area_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="sub_study_area_id">Sub Study Areas</label>
                <select id="sub_study_area_id" multiple class="form-control select <?php $__errorArgs = ['sub_study_area_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="sub_study_area_ids[]" data-live-search="true">
                    <option value="">----Select Sub Study Areas----</option>
                    <?php $__currentLoopData = config('sub_study_areas') ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(in_array($sub_area->id, old('sub_study_area_id')) ? "selected" : ""); ?> value=<?php echo e($sub_area->id); ?>><?php echo e($sub_area->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['sub_study_area_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <button type="submit" id="submit-btn" class="btn btn-primary">Add</button>
            </div>
    </div>
    </form>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/programs/create.blade.php ENDPATH**/ ?>