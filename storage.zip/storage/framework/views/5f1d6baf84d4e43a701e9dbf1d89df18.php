<?php
    $campus = App\Models\CampusProgram::find($row->campusprogram_id);
    $fees = $campus->fees;
    $feeTypeRecords = App\Models\FeeType::all();
    // foreach($feeTypeRecords as $feeTypeRecord) {
    //     $feeArr[\Str::slug($feeTypeRecord->name, "_")] = [];
    // }
    foreach ($fees as $fee) {
        $feeArr[\Str::slug($fee->fee->name, '_')] = [
            'price' => $fee->fee_price,
            'currency' => $fee->currency,
        ];
    }
?>
<div class="row px-md-1 py-1">
    <div class="col-12">
        
        <div class="row align-items-start">
            <div class="col-md-9 col-12">
                <h3><a target="_blank" class='text-dark'
                        href="<?php echo e(route('program-details', $row->campusprogram_id)); ?>"><?php echo e($row->program); ?> <i
                            class='fa text-light fa-external-link'></i></a></h3>
            </div>
            <div class="col-md-3 col-12 mt-1 mt-md-0 text-right">
                <?php if(auth()->check()): ?>
                    <?php if(is_null($row->shortlist_id)): ?>
                        <button class="btn btn-icon text-primary text-left  shortlist-add"
                            data-id="<?php echo e($row->campusprogram_id); ?>">
                            <span class="fa fa-heart"></span>
                            Shortlist
                        </button>
                    <?php else: ?>
                        <span class="text-primary"><i class="fa fa-check"></i> Shortlisted</span>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="row align-items-start mt-1">
            <div class="col-md-3 col-6">
                <?php if (isset($component)) { $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-text','data' => ['icon' => 'fa fa-university','heading' => 'University']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa fa-university','heading' => 'University']); ?>
                    <?php echo e($row->universtiy ?? 'N/A'); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $attributes = $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $component = $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
            </div>
            <div class="col-md-3 col-6">
                <?php if (isset($component)) { $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-text','data' => ['icon' => 'fa fa-map-marker','heading' => 'Campus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa fa-map-marker','heading' => 'Campus']); ?>
                    <?php if($row->campus): ?>
                        <a target="_blank" href="<?php echo e(route('campus-search', $row->campus_id)); ?>">
                            <?php echo e($row->campus); ?>

                            <i class="fa fa-external-link"></i>
                        </a>
                    <?php else: ?>
                        N/A
                    <?php endif; ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $attributes = $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $component = $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
            </div>
            <div class="col-md-3 col-6">
                <?php if (isset($component)) { $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-text','data' => ['icon' => 'fa fa-globe','heading' => 'Country']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa fa-globe','heading' => 'Country']); ?>
                    <?php echo e($row->country ?? 'N/A'); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $attributes = $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $component = $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
            </div>
            <div class="col-md-3 col-6">
                <?php if (isset($component)) { $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-text','data' => ['icon' => 'fa fa-clock-o','heading' => 'Duration']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa fa-clock-o','heading' => 'Duration']); ?>
                    <?php echo e($row->duration); ?> Month(s)
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $attributes = $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $component = $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
            </div>

        </div>
        
        <div class="row align-items-start mt-1">
            <div class="col-md-3 col-6">
                <?php if (isset($component)) { $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-text','data' => ['icon' => 'fa fa-money','heading' => 'Tuition Fees']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa fa-money','heading' => 'Tuition Fees']); ?>
                    <?php if(isset($feeArr['tuition_fees'])): ?>
                        <?php
                            $c_code = $feeArr['tuition_fees']['currency']->code == 'INR' ? '' : $feeArr['tuition_fees']['currency']->symbol;
                        ?>
                        <?php echo $feeArr['tuition_fees']['price'] == 0
                            ? 'N/A'
                            : $c_code . '' . $feeArr['tuition_fees']['price'] . ' ' . $feeArr['tuition_fees']['currency']->code; ?>

                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $attributes = $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $component = $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
            </div>
            <div class="col-md-3 col-6">
                <?php if (isset($component)) { $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-text','data' => ['icon' => 'fa fa-money','heading' => 'Application Fees']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa fa-money','heading' => 'Application Fees']); ?>
                    <?php if(isset($feeArr['application_fees'])): ?>
                        <?php echo $feeArr['application_fees']['price'] == 0
                            ? 'N/A'
                            : $c_code . '' . $feeArr['application_fees']['price'] . ' ' . $feeArr['application_fees']['currency']->code; ?>

                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $attributes = $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $component = $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
            </div>
            <div class="col-md-3 col-12">
                <?php if (isset($component)) { $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-text','data' => ['icon' => 'fa fa-user-plus','heading' => 'Intakes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa fa-user-plus','heading' => 'Intakes']); ?>
                    <?php $intakes = App\Models\CampusProgramIntake::where('campus_program_id', $row->campusprogram_id)->get(); ?>
                    <?php $__empty_1 = true; $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <span class="badge badge-primary mb-50"><?php echo e($intake->intake->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span>N/A</span>
                    <?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $attributes = $__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__attributesOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0)): ?>
<?php $component = $__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0; ?>
<?php unset($__componentOriginalb7f3298ee416117ab05ab9ca7042f6c0); ?>
<?php endif; ?>
            </div>

            <div class="col-md-3 col-12 mt-1 mt-md-0 text-right">
                <?php if(Auth::check()): ?>
                    <button type="button" class="btn btn-icon btn-outline-primary apply"
                        data-id="<?php echo e($row->campusprogram_id); ?>" data-toggle="modal" data-target="#apply-model">
                        <i class="fa fa-bullseye" aria-hidden="true"></i> Apply
                    </button>
                <?php else: ?>
                    <a class="btn btn-icon btn-outline-primary text-left apply-guest" href="<?php echo e(route('login')); ?>">
                        <i class="fa fa-user-circle" aria-hidden="true"></i> Login to Apply
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/course_finder/result.blade.php ENDPATH**/ ?>