<body
        class="vertical-layout vertical-menu-modern 2-columns <?php echo e($configData['blankPageClass']); ?> <?php echo e($configData['bodyClass']); ?> <?php echo e(($configData['theme'] === 'light') ? '' : $configData['layoutTheme']); ?>  <?php echo e($configData['verticalMenuNavbarType']); ?> <?php echo e($configData['sidebarClass']); ?> <?php echo e($configData['footerType']); ?>"
        data-menu="vertical-menu-modern" data-col="2-columns" data-layout="<?php echo e($configData['theme']); ?>">


<?php if(request()->segment(1) == 'admin'): ?>
    <?php echo $__env->make('panels.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('panels.student.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<!-- BEGIN: Content-->
<div class="app-content content">
    <!-- BEGIN: Header-->
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    
    <?php if(auth()->check() || auth('admin')->check()): ?>
        
        <?php if(request()->segment(1) == 'admin'): ?>
            <?php echo $__env->make('panels.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <div class="mobile-menu d-xl-none">
                <?php echo $__env->make('panels.student.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="header">
            <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endif; ?>

    <?php if(($configData['contentLayout']!=='default') && isset($configData['contentLayout'])): ?>
        <div class="content-area-wrapper">
            <div class="<?php echo e($configData['sidebarPositionClass']); ?>">
                <div class="sidebar">
                    
                    <?php echo $__env->yieldContent('content-sidebar'); ?>
                </div>
            </div>
            <div class="<?php echo e($configData['contentsidebarClass']); ?>">
                <div class="content-wrapper">
                    <div class="content-body">
                        
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="content-wrapper">
            
            <?php if($configData['pageHeader'] === true && isset($configData['pageHeader'])): ?>
                <?php echo $__env->make('panels.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <div class="content-body">
                
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('dashboard.inc.modal.side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    <?php endif; ?>

</div>
<!-- End: Content-->

<?php if($configData['blankPage'] == false && isset($configData['blankPage'])): ?>



<?php endif; ?>

<div class="sidenav-overlay"></div>
<div class="drag-target"></div>


<?php echo $__env->make('panels/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('panels/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/layouts/verticalLayoutMaster.blade.php ENDPATH**/ ?>