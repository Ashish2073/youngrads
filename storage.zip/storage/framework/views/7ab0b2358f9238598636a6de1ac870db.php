<div class="login-footer text-center">
    <div class="divider">
        <div class="divider-text">OR</div>
    </div>
    <div class="footer-btn d-inline">
        <a href="<?php echo e(route('auth.social.login', 'facebook')); ?>" class="btn btn-facebook"><span class="fa fa-facebook"></span></a>
        <a href="<?php echo e(route('auth.social.login', 'google')); ?>" class="btn btn-google"><span class="fa fa-google"></span></a>
    </div>
</div><?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/auth/social_login.blade.php ENDPATH**/ ?>