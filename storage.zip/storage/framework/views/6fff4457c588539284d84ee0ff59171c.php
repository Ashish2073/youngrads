<div class="d-flex">
    <div class="">
        <span class="<?php echo e($icon); ?> text-primary pr-1" ></span>
    </div>
    <div class="">
        <h5><?php echo e($heading); ?></h5>
        <span style="white-space: normal;">
            <?php echo $slot; ?>

        </span>
    </div>
</div><?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/components/icon-text.blade.php ENDPATH**/ ?>