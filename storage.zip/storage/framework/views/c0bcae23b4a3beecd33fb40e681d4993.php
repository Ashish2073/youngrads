<div class="row">
  <div class="col-md-12">
      <?php echo $__env->make('dashboard.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <form id="city-create-form" action="<?php echo e(route('admin.city.update', $city->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <?php echo $__env->make('dashboard.common.fields.text', [
              'label_name' => 'Name',
              'id' => 'name',
              'name' => 'name',
              'placeholder' => 'Enter City Name',
              'input_attribute' => [
                  'type' => 'text',
                  'value' => old('code', $city->name),
              ],
              'classes' => '',
          ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="form-group">
            <label for="state">State</label>
            <select class="select-2 form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="state" name="state">
              <option value="<?php echo e($city->getState->id); ?>"><?php echo e($city->getState->name); ?></option>
            </select>
            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
              <button type="submit" id="submit-btn" class="btn btn-primary">Update</button>
          </div>
  </div>
  </form>
  <?php if($city->address->count() > 0): ?>
    <div class="col-md-12">
        <p><?php echo e(config('setting.delete_notice')); ?></p>
    </div>
  <?php else: ?>
      <div class="form-group delete mx-1" style="margin-top:1%">
        <form  id="delete-form" method="POST" action="<?php echo e(route('admin.city.destroy', $city->id)); ?>" >
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
            <button type="submit" id="submit-btn-delete" class="btn btn-danger">Delete</button>
          </form>
        </div>
  <?php endif; ?>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/cities/edit.blade.php ENDPATH**/ ?>