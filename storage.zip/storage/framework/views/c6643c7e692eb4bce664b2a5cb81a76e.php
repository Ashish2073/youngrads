<div class="form-group">
    <label for="<?php echo e($id); ?>"><?php echo e($label_name ?? ""); ?></label>

    <input
            name="<?php echo e($name); ?>"
            id="<?php echo e($id); ?>"
            class="<?php echo e($classes); ?> form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(isset($input_attribute['value']) ? $input_attribute['value'] : ""); ?>"
            type="<?php echo e(isset($input_attribute['type']) ? $input_attribute['type'] : ""); ?>"
            placeholder="<?php echo e($placeholder); ?>"
    >
    <?php if(isset($help_text)): ?>
        <span class="text-muted"><?php echo e($help_text ?? ""); ?></span>
    <?php endif; ?>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <?php echo errMsg($message); ?>

    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/common/fields/text.blade.php ENDPATH**/ ?>