
<div class="row">
    <div class="col">
        <?php echo $__env->make('dashboard.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<form id="course-create-form" action="<?php echo e(route('admin.campus.store')); ?>" method="post">
    <div class="row">
        <div class="col-md-6 col-12">
            <h4>Campus Information</h4>
            <hr />
            <?php echo csrf_field(); ?>

            <?php echo $__env->make('dashboard.common.fields.text', [
            'label_name' => 'Campus',
            'id' => 'name',
            'name' => 'name',
            'placeholder' => 'Enter Campus Name',
            'input_attribute' => [
            'type' => 'text',
            'value' => old('name'),
            ],
            'classes' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <div class="form-group">
                <label for="university">University</label>
                <select class='form-control university <?php $__errorArgs = [' university'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>' name="university"
                    data-live-search="true">
                    <option value="">--Select University--</option>
                    <?php $__currentLoopData = config('universities'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $univ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($univ->id == old('university') ? 'selected' : ''); ?> value="<?php echo e($univ->id); ?>">
                            <?php echo e($univ->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['university'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php echo $__env->make('dashboard.common.fields.text', [
            'label_name' => 'Website',
            'id' => 'website',
            'name' => 'website',
            'placeholder' => 'Enter Website',
            'input_attribute' => [
            'type' => 'url',
            'value' => old('website'),
            ],
            'classes' => '',
            'help_text' => 'e.g http(s)://example.com'
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('dashboard.common.fields.text', [
            'label_name' => 'Logo',
            'id' => 'logo',
            'name' => 'logo',
            'placeholder' => 'Campus Logo',
            'input_attribute' => [
            'type' => 'file',
            'value' => old('logo'),
            ],
            'classes' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            


            
        </div>
        <div class="col-md-6 col-12">
            <h4>Address Details</h4>
            <hr>
            <?php echo $__env->make('dashboard.common.fields.text', [
            'label_name' => 'Address',
            'id' => 'address',
            'name' => 'address',
            'placeholder' => 'Enter Campus Address',
            'input_attribute' => [
            'type' => 'text',
            'value' => old('address'),
            ],
            'classes' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="form-group">
                <label for="country">Country</label>
                <select  class='form-control country_id <?php $__errorArgs = [' country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>' name="country"
                    id="country" data-live-search="true">
                    <option value="">--Select Country--</option>
                    <?php $__currentLoopData = config('countries'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($country->id == old('country') ? 'selected' : ''); ?> value="<?php echo e($country->id); ?>">
                            <?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="state">State</label>
                <select class='form-control select <?php $__errorArgs = [' state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>' name="state" id="state"
                    data-live-search="true">
                    <option value="">--Select State--</option>
                    <?php $__currentLoopData = config('states'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($state->id == old('state', $campus->address->state_id) ? 'selected' : ''); ?>

                            value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="city">City</label>
                <select class='form-control select <?php $__errorArgs = [' city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>' name="city" id="city"
                    data-live-search="true">
                    <option value="">--Select City--</option>
                    <option value='new-city'>Add New City</option>
                    <?php $__currentLoopData = config('cities'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($city->id == old('city') ? 'selected' : ''); ?> value="<?php echo e($city->id); ?>">
                            <?php echo e($city->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="text" name="new_city" class="form-control mt-2 d-none" placeholder="Enter new City Name"
                    id="new-city">
                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="form-group">
                <button type="submit" id="submit-btn" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/campus/create.blade.php ENDPATH**/ ?>