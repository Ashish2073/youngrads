<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>