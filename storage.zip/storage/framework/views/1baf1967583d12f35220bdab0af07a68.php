<?php $__env->startSection('title', 'Course Finder'); ?>
<?php $__env->startSection('vendor-style'); ?>
    <!-- vendor css files -->
    <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/nouislider.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/pages/app-chat.css'))); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
    <!-- Page css files -->
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/plugins/extensions/noui-slider.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/core/colors/palette-noui.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset(mix('css/pages/data-list-view.css'))); ?>">
    <style>
        /* .select2-results__option .wrap:before{
                          font-family:fontAwesome;
                          color:#999;
                          content:"\f096";
                          width:25px;
                          height:25px;
                          padding-right: 10px;

                      }
                      .select2-results__option[aria-selected=true] .wrap:before{
                          content:"\f14a";
                      } */
        tr {
            box-shadow: 0 0.5rem 1rem rgba(34, 41, 47, 0.15) !important;
        }

        /* .bs-select-all, .bs-select-all:hover,.bs-deselect-all, .bs-deselect-all:hover  {
                        background: white!important;
                        color: black!important;
                        border: 1px solid #babfc7 !important;
                      }
                      .dropdown-header {
                          font-weight: bold!important;
                          color: #626262;
                          cursor: pointer;
                      }
                      .dropdown .dropdown-menu::before {
                          content: unset!important;
                      }
                      .dropdown-toggle:focus {
                        outline-color: white!important;
                      } */
        ist-view.dataTable tbody tr,
        table.data-thumb-view.dataTable tbody tr {
            cursor: default;
        }

        .sticky {
            position: fixed !important;
            top: 0;
            z-index: 999999;
        }

        .card-header {
            position: relative !important;
        }
    </style>

    <style>
        @media(max-width: 1100px) {
            .chat-app-window .univ-box.user-chats .vs-checkbox-con {
                display: block;
            }

            .chat-app-window .univ-box.user-chats span.vs-checkbox {
                display: inline-block;
                width: 20px;
                vertical-align: top;
            }

            .chat-app-window .univ-box.user-chats span.font-weight-bold {
                display: inline-block;
                width: 75%;
            }
        }

        @media(max-width: 767px) {
            .univ-box.user-chats span.font-weight-bold {
                display: inline-block;
                width: 90%;
            }
        }

        @media(max-width: 480px) {
            .univ-box.user-chats span.font-weight-bold {
                display: inline-block;
                width: 80%;
            }
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="upper-section">
        
        <section class="">
            <div class="row justify-content-center align-items-end">
                <div class="col-md-3 col-sm-12">
                    <label class="h5 text-primary font-weight-bold" for="what">What you want to study?</label>
                    <input placeholder="Search for Courses/Keyword" type="text" name="what" class="form-control"
                        value="<?php echo e(request()->get('what')); ?>" id="what">
                </div>
                <div class="col-md-3 col-sm-12 mt-2 mt-md-0">
                    <label class="h5 text-primary font-weight-bold" for="">Where do you want to study?</label>
                    <input placeholder="Search for Country/Keyword" type="text" class="form-control"
                        value="<?php echo e(request()->get('where')); ?>" id="where">
                </div>
                <div class="col-md-3 col-sm-12 mt-2 mt-md-0 course-finder-year">
                    <label class="h5 text-primary font-weight-bold ">Year</label>
                    <select data-style="bg-white border-light" class="form-control select" id="ygrad_year" name="ygrad_year"
                        multiple>
                        <?php $g_year = !is_null(request()->get('year')) ? request()->get('year') : []; ?>
                        <?php for($i = date('Y'); $i < date('Y') + 3; $i++): ?>
                            <option <?php echo e(in_array($i, $g_year) ? 'selected' : ''); ?> value="<?php echo e($i); ?>">
                                <?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-3 top-search-options col-sm-12 text-md-right text-sm-center text-center  mt-2 mt-md-0">
                    <button type="button" class="btn btn-icon btn-outline-primary reset-search">Reset
                    </button>
                    <button type="button" class="btn btn-icon btn-primary search-submit">Search
                    </button>
                </div>
            </div>
            <div class="row justify-content-center mt-2 text-center">
                <div class="col-12">
                    <button class="btn btn-icon btn-primary toggle-advance"><span class="fa fa-search"></span> Advance
                        Search</button>
                </div>
            </div>
        </section>

        
        <section class=" mt-2 d-none advance-search-box">
            <div class="card">
                <div class="card-content">
                    <div class="card-body">
                        <div id="advance-search-box">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="h5 text-primary font-weight-bold" for="program-level">Program
                                            Level</label>
                                        <select data-actions-box="true" data-style="bg-white border-light"
                                            class="form-control select" id="program-level" name="programlevel[]" multiple>
                                            <?php $__currentLoopData = $programLevels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programLevel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($programLevel->id); ?>"><?php echo e($programLevel->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="h5 text-primary font-weight-bold" for="">Intakes</label>
                                        <select data-actions-box="true" data-style="bg-white border-light"
                                            class="form-control select" id="intakes" name="intakes" multiple>
                                            <optgroup label="Jan - April">
                                                <?php $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($intake->group_name == 'Jan'): ?>
                                                        <option <?php if($selectedIntake == $intake->id): ?> selected <?php endif; ?>
                                                            value="<?php echo e($intake->id); ?>"><?php echo e($intake->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                            <optgroup label="May - Aug">
                                                <?php $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($intake->group_name == 'May'): ?>
                                                        <option <?php if($selectedIntake == $intake->id): ?> selected <?php endif; ?>
                                                            value="<?php echo e($intake->id); ?>"><?php echo e($intake->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                            <optgroup label="Sep - Dec">
                                                <?php $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($intake->group_name == 'Sep'): ?>
                                                        <option <?php if($selectedIntake == $intake->id): ?> selected <?php endif; ?>
                                                            value="<?php echo e($intake->id); ?>"><?php echo e($intake->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                            <optgroup label="Season">
                                                <?php $__currentLoopData = $intakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($intake->type == 'Season'): ?>
                                                        <option <?php if($selectedIntake == $intake->id): ?> selected <?php endif; ?>
                                                            value="<?php echo e($intake->id); ?>"><?php echo e($intake->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="h5 text-primary font-weight-bold">Duration</label>
                                        <select data-style="bg-white border-light" class="form-control select"
                                            id="duration" name="duration" multiple>
                                            
                                            <?php $__currentLoopData = [
            '0 - 1 Years' => [0, 1],
            '1 - 2 Years' => [1, 2],
            '2 - 3 Years' => [2, 3],
            '3 - 4 Years' => [3, 4],
            '4 and above Years' => [4, 10],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duration => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e(json_encode($value)); ?>"><?php echo e($duration); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="h5 text-primary font-weight-bold"
                                            for="special-test">Requirements</label>
                                        <select data-actions-box="true" data-style="bg-white border-light"
                                            class="form-control select" id="special-test" name="special_test[]" multiple>
                                            <?php $__currentLoopData = $special_tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $special_test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($special_test->id); ?>"><?php echo e($special_test->test_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="h5 text-primary font-weight-bold">Country</label>
                                        <select data-live-search="true" data-style="bg-white border-light"
                                            class="form-control select" id="country" name="countries[]" id="country"
                                            multiple>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label class="h5 text-primary font-weight-bold">Study Area</label>
                                        <select data-live-search="true" data-style="bg-white border-light"
                                            class="form-control select" id="study-area" name="study_area[]"
                                            id="study-area" multiple>
                                            <?php $__currentLoopData = $studyAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studyArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($studyArea->id); ?>"><?php echo e($studyArea->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <?php
                                        $selectedDiscipline = DB::table('programs')
                                            ->where('id', request()->get('program'))
                                            ->first();
                                    ?>
                                    <div class="form-group">
                                        <label class="h5 text-primary font-weight-bold">Discipline Area</label>
                                        <select data-live-search="true" data-style="border-light bg-white"
                                            class="form-control select" id="discipline-area" name="discipline[]"
                                            multiple>
                                            <?php if(isset($selectedDiscipline)): ?>
                                                <option value="<?php echo e($selectedDiscipline->id); ?>" selected>
                                                    <?php echo e($selectedDiscipline->name); ?></option>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row align-items-end">
                                
                                <div class="col-md-3"></div>
                                <div class="col-md-3 text-right">
                                    <button type="button"
                                        class="btn btn-icon btn-outline-primary reset-search">Reset</button>
                                    <button type="button" class="btn btn-icon btn-primary search-submit">Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>

        </section>
    </div>



    <section id="search-result-section" class="mt-2">
        <div class="card">
            <div class="card-header">
                <div class="row w-100 align-items-center">
                    <div class="col-md-3 col-12">
                        <h2 class="filter-title"><span class="fa fa-filter"></span> Filters</h2>
                    </div>
                    <div class="col-md-6 col-12 mt-1 mt-md-0">
                        <h2 class='d-inline-block'>Search Results</h2> <span
                            class="d-inline-block dx-1 result-count text-primary font-weight-bold"></span>
                    </div>
                    <div class="col-md-3 mt-1 mt-md-0 col-12 pr-0 text-md-right">
                        <?php $f=2;?>
                        <div class="d-inline-block w-50">
                            <select data-style="bg-white border-light" id="col-sorting" class="form-control select">
                                <option value="">Sort by</option>
                                <optgroup label="Program Fees">
                                    <?php $__currentLoopData = $feeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feeType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($feeType->name == 'Admission Fees'): ?>
                                            <?php $f++; ?> <?php continue; ?>
                                        <?php endif; ?>
                                        <option value="<?php echo e($f); ?>"><?php echo e($feeType->name); ?></option>
                                        <?php $f++;?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                                <optgroup label="Other">
                                    <option value="<?php echo e($f); ?>">Country</option> <?php $f++; ?>
                                    <option value="<?php echo e($f); ?>">Duration</option><?php $f++; ?>
                                    <option value="<?php echo e($f); ?>">University</option>
                                </optgroup>
                            </select>
                        </div>
                        <div class="d-inline-block">
                            <button id="sort-order" data-val="ASC" class='btn btn-outline-light btn-icon'>
                                <i class="fa fa-sort-amount-asc text-dark"></i>
                            </button>
                            
                        </div>

                    </div>
                </div>
            </div>
            <div class="card-content">
                <div class="card-body pt-0">
                    <div class="row">
                        <div class="col-md-3 col-12 pt-2">
                            <div class="card chat-widget">
                                <div class="card-header bg-primary  rounded" style="padding: 8px;">
                                    <h4 class="card-title text-white">Universities</h4>
                                </div>
                                <div class="chat-app-window">
                                    <div class="univ-box user-chats text-left px-0 pl-1 py-0"
                                        style="height: auto; max-height: 200px;">
                                        <?php $__empty_1 = true; $__currentLoopData = config('universities'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $univ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div data-toggle='tooltip' title="<?php echo e(html_friendly($univ->name)); ?>"
                                                class="vs-checkbox-con vs-checkbox-primary mt-1">
                                                <input name='univs[]' id="univ_<?php echo e($univ->id); ?>"
                                                    value="<?php echo e($univ->id); ?>" type="checkbox" />
                                                <span class="vs-checkbox">
                                                    <span class="vs-checkbox--check">
                                                        <i class="vs-icon feather icon-check"></i>
                                                    </span>
                                                </span>
                                                <span class="font-weight-bold">
                                                    <?php echo \Str::limit($univ->name, 30); ?>

                                                </span>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <div class="p-1"><strong>No universities found</strong></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="chat-footer d-none">
                                        <div class="card-body d-flex justify-content-around pt-0">
                                            <input type="text" class="form-control mr-50"
                                                placeholder="Type your Message">
                                            <button type="button" class="btn btn-icon btn-primary"><i
                                                    class="feather icon-navigation"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card chat-widget d-none">
                                <div class="card-header bg-primary  rounded" style="padding: 8px;">
                                    <h4 class="card-title text-white">Program Levels</h4>
                                </div>
                                <div class="chat-app-window">
                                    <div class="program-level-box user-chats text-left px-0 pl-1 py-0 pt-1"
                                        style="height: auto; max-height: 200px;">
                                        <?php $__currentLoopData = config('program_levels'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div>
                                                <label class="h5 text-left " for="level_<?php echo e($level->id); ?>">
                                                    <input id="level_<?php echo e($level->id); ?>" type="checkbox" />
                                                    <?php echo e($level->name); ?>

                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="chat-footer d-none">
                                        <div class="card-body d-flex justify-content-around pt-0">
                                            <input type="text" class="form-control mr-50"
                                                placeholder="Type your Message">
                                            <button type="button" class="btn btn-icon btn-primary"><i
                                                    class="feather icon-navigation"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <?php $__currentLoopData = $feeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feeType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group <?php echo e($feeType->name == 'Admission Fees' ? 'd-none' : ''); ?>">
                                    <h4 class="my-1"><?php echo e($feeType->name); ?></h4>
                                    <div id="slider-<?php echo e($feeType->id); ?>" class="my-1 fee-slider"
                                        data-fee ="<?php echo e(Str::slug($feeType->name, '_')); ?>"></div>
                                    <div class="">
                                        <span class="<?php echo e(Str::slug($feeType->name, '_')); ?>-min">left</span> <span
                                            class="float-right <?php echo e(Str::slug($feeType->name, '_')); ?>-max">right</span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>

                        <div class="col-md-9 col-12 px-0">
                            <section id="data-thumb-view" class="data-thumb-view-header">
                                
                                <div class="table-responsive">
                                    <table id="result-search" class="table data-thumb-view w-100  border-0"
                                        style="width:100%">
                                        <thead class="d-none">
                                            <th>Logo</th>
                                            <th>Search Results</th>
                                            <?php $__currentLoopData = $feeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feeType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th><?php echo e(Str::slug($feeType->name, '_')); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <th>Country</th>
                                            <th>Duration</th>
                                            <th>University</th>
                                        </thead>
                                    </table>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vendor-script'); ?>
    <!-- vendor files -->
    <script src="<?php echo e(asset(mix('vendors/js/extensions/wNumb.js'))); ?>"></script>
    <script src="<?php echo e(asset(mix('vendors/js/extensions/nouislider.min.js'))); ?>"></script>
    
    <script>
        // Chat Application
        (function($) {
            "use strict";
            // Chat area
            if ($('.program-level-box').length > 0) {
                var chat_user = new PerfectScrollbar(".program-level-box", {
                    wheelPropagation: false
                });
            }
            if ($('.univ-box').length > 0) {
                var chat_user = new PerfectScrollbar(".univ-box", {
                    wheelPropagation: false
                });
            }

        })(jQuery);
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
    <script>
        var fee = {};
        var feePrice = {};

        $(document).ready(function() {
            initPlugins();
            initResultTable();

            // Toggle advance search
            $(".toggle-advance").on("click", function() {
                $(".advance-search-box").toggleClass('d-none', 1000);
                $(".top-search-options").toggleClass('d-none', 1000);
            });

            // Handle Sorting event
            $('#col-sorting').on('change', function() {
                sortColumn();
            });
            $('#sort-order').on('click', function() {
                if ($(this).attr('data-val') == "ASC") {
                    $(this).attr('data-val', "DESC");
                    $(this).attr('title', "Descending");

                    $(this).find("i").removeClass("fa-sort-amount-asc");
                    $(this).find("i").addClass("fa-sort-amount-desc");
                } else {
                    $(this).attr('data-val', "ASC");
                    $(this).attr('title', "Ascending");
                    $(this).find("i").removeClass("fa-sort-amount-desc");
                    $(this).find("i").addClass("fa-sort-amount-asc");
                }
                sortColumn();
            });

            // Shortlist program
            $(document).on('click', '.shortlist-add', function() {
                let that = $(this);

                $.ajax({
                    url: route('shortlist-programs-add'),
                    type: 'POST',
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        campus_program_id: $(this).data('id')
                    },
                    beforeSend: function() {
                        that.attr('disabled', true).prepend(
                            "<i class='fa fa-spinner fa-spin'></i> ");
                    },
                    success: function(data) {
                        that.removeAttr('disabled').html('ShortList');
                        setAlert(data);
                        dataTable.draw('page');
                    }
                });
            });

            // Remove program for shortlist
            $(document).on('click', '.remove', function() {
                let that = $(this);

                if (confirm('Are you sure  you want to remove this from shortlist ?')) {
                    $.ajax({
                        url: route('shortlist-programs-remove'),
                        type: 'POST',
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>",
                            id: $(this).data('id')
                        },
                        beforeSend: function() {
                            // shortlist-programs
                            that.attr('disabled', true).prepend(
                                "<i class='fa fa-spinner fa-spin'></i> ");
                        },
                        success: function(data) {
                            setAlert(data);
                            dataTable.draw('page');
                            that.removeAttr('disabled').html('Remove');
                        }
                    });
                }
            });

            // Apply for Program
            $(document).on('click', '.apply', function() {
                id = $(this).data('id')
                $('.apply-title').text('Apply Now');
                $.ajax({
                    url: route('apply-application', id),
                    beforeSend: function() {
                        $('.dynamic-apply').html("Loading");
                    },
                    success: function(data) {
                        $('.dynamic-apply').html(data);
                    }
                })
            });

            // Filter by Universities
            $(document).on("change", "input[name='univs[]']", function() {
                dataTable.draw();
            });

            // Show subareas based on Study Area
            $('#study-area').change(function() {
                let programOption = '';
                // let id = $(this).val();
                let arr = [];
                $("#study-area").find("option:selected").each(function(value, index) {
                    arr.push($(this).val());
                })
                // if(id != ''){
                $.ajax({
                    url: route('get-sub-areas'),
                    type: 'post',
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        ids: arr
                    },
                    beforeSend: function() {
                        $('#discipline-area').html("");
                        $('#discipline-area').selectpicker("refresh");

                    },
                    success: function(data) {
                        // data.forEach(program => {
                        //     programOption += `<option value='${program.id}'>${program.name}</option>`;
                        // });
                        programOption = "";
                        data.forEach(function(program) {
                            name = program.name;
                            if (program.name.length > 50) {
                                //name = program.name.substr(0, 50) + "...";
                                name = program.name;
                            }
                            return programOption +=
                                `<option value='${program.id}'>${name}</option>`;
                        })
                        // $('#discipline-area').find('option').remove().end();
                        $('#discipline-area').html(programOption);
                        $("#discipline-area").selectpicker('refresh');
                    }
                })
                // }

            });

            // Submit Search
            $(".search-submit").on("click", function() {
                $('html, body').animate({
                    scrollTop: $("#search-result-section").offset().top
                }, 1000);
                dataTable.draw();
            });

            // Toggle Advance Search
            $('#advance-search').on('click', function() {
                $('#advance-search-box').toggleClass('d-none');
                if ($("#advance-search-box").hasClass('d-none')) {
                    $(this).html("Show Advance Search");
                } else {
                    $(this).html("Hide Advance Search");
                }
                $(".search-submit-no-auth").toggleClass('d-none');
            });

            // Reset Search
            $(document).on('click', '.reset-search', function() {
                resetSearch();
            });
        });
    </script>
    <script>
        function enableBoostrapSelectOptgroup() {
            let that = $(this).data('selectpicker'),
                inner = that.$menu.children('.inner');

            // remove default event
            inner.off('click', '.divider, .dropdown-header');
            // add new event
            inner.on('click', '.divider, .dropdown-header', function(e) {
                // original functionality
                e.preventDefault();
                e.stopPropagation();
                if (that.options.liveSearch) {
                    that.$searchbox.trigger('focus');
                } else {
                    that.$button.trigger('focus');
                }

                // extended functionality
                let position0 = that.isVirtual() ? that.selectpicker.view.position0 : 0,
                    clickedData = that.selectpicker.current.data[$(this).index() + position0];

                // copied parts from changeAll function
                let selected = null;
                for (let i = 0, data = that.selectpicker.current.data, len = data.length; i < len; i++) {
                    let element = data[i];
                    if (element.type === 'option' && element.optID === clickedData.optID) {
                        if (selected === null) {
                            selected = !element.selected;
                        }
                        element.option.selected = selected;
                    }
                }
                that.setOptionStatus();
                that.$element.triggerNative('change');
            });
        }

        function initPlugins() {
            $(".select").selectpicker();
            $('.select').selectpicker().on('loaded.bs.select', enableBoostrapSelectOptgroup);
            $('#col-sorting').selectpicker();
            $('#sort-order').selectpicker();
            $('#col-sorting').selectpicker();
            $('#sort-order').selectpicker();
            $('.select-2').select2({
                placeholder: '--Select--',
                width: '100%'
            });
            $(".select-2").selectpicker();
            $('#discipline-area').selectpicker();

            fees = {};
            feePrice = {};

            $(".fee-slider").each(function() {
                let min = 0;
                let max = 99999;
                let fee_key = $(this).data('fee');
                fees[fee_key] = $(this)[0];
                feePrice[fee_key] = ["", ""];
                noUiSlider.create(fees[fee_key], {
                    start: [min, max],
                    connect: true,
                    decimals: 0,
                    step: 500,
                    range: {
                        'min': min,
                        'max': max
                    }
                });

                fees[fee_key].noUiSlider.on('update', function(values, handle) {
                    key = this.target.dataset.fee;
                    $('.' + key + '-min').text(values[0]);
                    $('.' + key + '-max').text(values[1]);
                    feePrice[key] = values;
                });
                fees[fee_key].noUiSlider.on('change', function(values, handle) {
                    dataTable.draw();
                });
            });
        }

        function initResultTable() {
            dataTable = $("#result-search").DataTable({
                "processing": true,
                "serverSide": true,
                "pageLength": 100,
                ajax: {
                    url: "<?php echo e(route('getprogram')); ?>",
                    data: function(d) {
                        d.what = $('#what').val();
                        d.where = $('#where').val();

                        d.program_levels = $("#program-level").val();
                        d.intakes = $('#intakes').val();
                        d.duration = $('#duration').val();
                        d.special_tests = $("#special-test").val();
                        d.country_id = $("#country").val();
                        d.study_area = $('#study-area').val();
                        d.discipline = $('#discipline-area').val();

                        let univs = [];
                        $('input[name="univs[]"]:checked').each(function(i) {
                            univs.push($(this).val());
                        });
                        d.univs = univs;
                        d.fee = feePrice;

                        if ($("#col-sorting").val() !== "" && $("#sort-order").attr('data-val') !== "") {
                            d.order[0].column = $("#col-sorting").val();
                            d.order[0].dir = $("#sort-order").attr('data-val');
                        }

                        console.log("Request", d);
                    },
                    beforeSend: function() {
                        $('.filter-title').append("   <i class='fa fa-spin fa-spinner'></i>");
                    },
                    complete: function(data) {
                        $('.filter-title').html("<span class='fa fa-filter'></span> Filters");
                        $(".result-count").html("<u>" + data.responseJSON.recordsTotal + " Programs found</u>");
                        $('html, body').animate({
                            scrollTop: $("#search-result-section").offset().top
                        }, 1000);
                        // try {
                        //     let univs = data.responseJSON.universities;
                        //     renderUnivs(univs);
                        // } catch(e) {
                        //     console.log("Error", e);
                        // }
                    }
                },
                columns: [{
                        data: 'logo',
                        "visible": false
                    },
                    {
                        data: 'row',
                    },
                    <?php $__currentLoopData = $slugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        {
                            data: "<?php echo e($slug); ?>",
                            "visible": false
                        },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> {
                        data: 'country',
                        name: 'countries.name',
                        visible: false
                    },
                    {
                        data: 'duration',
                        name: 'campus_programs.campus_program_duration',
                        visible: false
                    },
                    {
                        data: 'universtiy',
                        name: 'universities.name',
                        visible: false
                    },

                ],
                responsive: false,
                // columnDefs: [
                //     {
                //         orderable: true,
                //         targets: 0,
                //         checkboxes: { selectRow: true }
                //     }
                // ],
                drawCallback: function(setting, data) {
                    $(".table-img").each(function() {
                        $(this).parent().addClass('product-img');
                        $(this).parent().addClass('text-center');
                    });
                },
                // dom:'<"top"<"actions action-btns"><"action-filters">><"clear">rt<"bottom"<"actions">p>',
                dom: '<"clear">rt<"bottom"<"actions">p>',
                oLanguage: {
                    sLengthMenu: "_MENU_",
                    sSearch: "",
                    sEmptyTable: "No results found"
                },
                aLengthMenu: [
                    [10, 15, 20],
                    [10, 15, 20]
                ],
                // select: {
                //     style: "multi"
                // },
                // order: [[1, "asc"]],
                bInfo: false,
                pageLength: 10,
                buttons: [{
                    text: "<i class='feather icon-plus'></i> Add New",
                    action: function() {
                        $(this).removeClass("btn-secondary")
                        $(".add-new-data").addClass("show")
                        $(".overlay-bg").addClass("show")
                        $("#data-name, #data-price").val("")
                        $("#data-category, #data-status").prop("selectedIndex", 0)
                    },
                    className: "btn-outline-primary"
                }],
                initComplete: function(settings, json) {
                    $(".dt-buttons .btn").removeClass("btn-secondary");
                    $(".table-img").each(function() {
                        $(this).parent().addClass('product-img');
                    });
                }
            });
        }

        function resetSearch() {
            // Input box
            $('#what').val("");
            $("#where").val("");

            // Select pickers
            $(".select").selectpicker('deselectAll');
            $(".select").val("");
            $(".select").selectpicker('refresh');

            // Checkboxes
            $('input[name="univs[]"]').prop("checked", false);

            // Program Fees
            for (fee_key in fees) {
                fees[fee_key].noUiSlider.reset();
            }
            dataTable.draw();
        }

        function sortColumn() {
            let column = $('#col-sorting').val();
            let order = $("#sort-order").attr('data-val');
            if (column != "" && order != "") {
                dataTable.order([column, order]).draw();
            }
        }



        function renderUnivs(univs) {
            let html = '';
            for (id in univs) {
                let checked = univs[id].checked ? 'checked' : '';
                html += `
                    <div class="vs-checkbox-con vs-checkbox-primary mt-1">
                        <input ${checked} name='univs[]' id="univ_${id}" value="${id}" type="checkbox" />
                        <span class="vs-checkbox">
                            <span class="vs-checkbox--check">
                                <i class="vs-icon feather icon-check"></i>
                            </span>
                        </span>
                        <span class="font-weight-bold">
                            ${univs[id].name}
                        </span>
                    </div>
                `;
            }
            $(".univ-box").html(html);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/course_finder/index.blade.php ENDPATH**/ ?>