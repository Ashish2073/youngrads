<?php if(!is_null($application_docs)): ?>
    <h4>
        Application Specific Documents
    </h4>
    <div class="d-flex flex-wrap">
        <?php $__currentLoopData = $application_docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <label class=""><?php echo e($document->name); ?></label>
                <div class="d-flex flex-wrap">

                    <?php $__empty_1 = true; $__currentLoopData = $document->uploaded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="item mr-50">
                            <div class="badge badge-primary dropdown p-50 mb-50">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="true">
                                    <i class="feather icon-paperclip"></i>
                                    <span><?php echo e($document->name); ?></span>
                                </a>
                                <div class="dropdown-menu" x-placement="bottom-start">
                                    <a class="dropdown-item" download
                                        href="<?php echo e(asset($doc->documentFile->file->location)); ?>">
                                        <i class='fa fa-download'></i> Download
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <strong>N/A</strong>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <hr/> 
<?php endif; ?>  

<?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $document_type = $document['document_type']; ?>
    
    <h4>
        <?php echo e($document['group_name']); ?>

    </h4>

    <div class="d-flex flex-wrap">
        <?php $__empty_1 = true; $__currentLoopData = $document['document_lists'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="item mr-50">
                <label class=""><?php echo e($list['name']); ?></label>
                <div class="d-flex align-items-top flex-wrap">
                    <?php $__empty_2 = true; $__currentLoopData = $list['document_list'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <div class="item mr-50">
                            <?php $__empty_3 = true; $__currentLoopData = $list->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_3 = false; ?>
                                <div class="badge badge-primary dropdown p-50 mb-50">
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"
                                        aria-expanded="true">
                                        <i class="feather icon-paperclip"></i>
                                        <span><?php echo e($list->name); ?></span>
                                    </a>
                                    <div class="dropdown-menu " x-placement="bottom-left" >
                                        <a class="dropdown-item" download
                                            href="<?php echo e(asset($doc->documentFile->file->location)); ?>">
                                            <i class='fa fa-download'></i> Download
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_3): ?>
                                <strong>N/A</strong>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <strong>N/A</strong>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <strong>N/A</strong>
            </div>
        <?php endif; ?>
    </div>

    <hr/>   
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<h4>
    Other Documents
</h4>
<div class="d-flex flex-wrap" >
    <?php $__empty_1 = true; $__currentLoopData = $other_docs ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other_document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="item mr-50">
            <div class="badge badge-primary dropdown p-50 mb-50">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#"
                    aria-expanded="true">
                    <i class="feather icon-paperclip"></i>
                    <span><?php echo e($other_document->document_name); ?></span>
                </a>
                <div class="dropdown-menu" x-placement="bottom-start">
                    <a class="dropdown-item" download
                        href="<?php echo e(asset($other_document->documentFile->file->location)); ?>">
                        <i class='fa fa-download'></i> Download
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <strong>N/A</strong>
        </div>
    <?php endif; ?>
</div>
<hr/>   
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/student/profile/view/document.blade.php ENDPATH**/ ?>