
<?php
// dd(config('documents'));
?>
<div class="row">
    <div class="col-12 ">
        <?php $__currentLoopData = config('documents'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $document_type = $document['document_type']; ?>
            <div class="">
                <div class="">
                    <h4 class="">
                        <?php echo e($document['group_name']); ?>

                    </h4>
                </div>
                <div class="">
                    <div class="">
                        <div class="row ">
                        <?php $__empty_1 = true; $__currentLoopData = $document['document_lists'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if($document_type == 'study_levels' && $list['name'] == 'Other'): ?>
                                <?php continue; ?>
                            <?php endif; ?>
                            <div class="col-md-4">
                                <div class="p-1 mb-1 shadow border" style="border-radius: 0.5rem; box-shadow: unset;">
                                    <h4 class="card-title"><?php echo e($list['name']); ?> 
                                    </h4>
                                    <div class="">
                                        <div class="row align-items-top">
                                            <?php $__empty_2 = true; $__currentLoopData = $list['document_list'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>

                                                <div class="col-12">
                                                    <form data-file="<?php echo e($list->documents->count() == 0 ? 0 : 1); ?>" class="document-upload-form mb-2" method="post"
                                                        action="<?php echo e(route('student.document.upload')); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="document_type_id"
                                                            value="<?php echo e($list->id); ?>">
                                                        <input type="hidden" name="document_type"
                                                            value="<?php echo e($document_type); ?>">
                                                        <input type="hidden" name="document_name"
                                                            value="<?php echo e($list->name); ?>" />
                                                        <div class="form-group mb-50">
                                                            <?php if($document_type != 'document_types'): ?>
                                                                <label for=""><?php echo e($list->name); ?></label><span class="required text-danger">*</span>
                                                            <?php endif; ?>
                                                            <div class="custom-file">
                                                                <input name="document_file" type="file"
                                                                    class="custom-file-input">
                                                                <label class="custom-file-label">
                                                                    <?php if($list->documents->count() == 0): ?>
                                                                        Choose file
                                                                    <?php else: ?>
                                                                        Replace file
                                                                    <?php endif; ?>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div class="form-group progress-indicator d-none">
                                                            <div class="progress progress-bar-primary progress-xl">
                                                                <div class="progress-bar" style="width:0%">0%</div>
                                                            </div>
                                                        </div>
                                                        <?php $__currentLoopData = $list->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="badge badge-primary dropdown p-50">
                                                                <a class="dropdown-toggle" data-toggle="dropdown" href="#"
                                                                    aria-expanded="false">
                                                                    <i class="feather icon-paperclip"></i>
                                                                    <span><?php echo e($list->name); ?></span>
                                                                </a>
                                                                <div class="dropdown-menu" x-placement="bottom-start">
                                                                    <a class="dropdown-item delete-document"
                                                                        data-url="<?php echo e(route('student.document.delete', $doc->id)); ?>">
                                                                        <i class="fa fa-trash"></i> Delete</a>
                                                                    <a class="dropdown-item" download
                                                                        href="<?php echo e(asset($doc->documentFile->file->location)); ?>">
                                                                        <i class='fa fa-download'></i> Download
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </form>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <span>N/A</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-md-4">
                                <span>N/A</span>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="">
            <div class="d-flex align-items-center mb-2">
                <div class="item mr-2">
                    <h4 class="">
                        Other Documents
                    </h4>
                </div>
                <div class="item">
                    <button id='add-document-btn' data-url="<?php echo e(route('other_document.create')); ?>" class='btn btn-icon btn-outline-primary'> Add Document</button>
                </div>
                
            </div>
            <div class="">
                <div class="">
                    <div class="row">
                        <div class="col-12">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                           <div id="document-action-box">

                           </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div id="document-listing-box">
                                <?php $__empty_1 = true; $__currentLoopData = config('other_documents'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other_document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php echo $__env->make('student.documents.create', compact('other_document'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="mb-2">No other documents added yet.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <button type="button" class="btn btn-primary previous">Previous</button>
    </div>
</div>

<script>
    function uploadDocumentScript() {
        var form;
        submitForm($('.document-upload-form'), {
            beforeSubmit: function(formData, jqForm, options) {
                if(jqForm.data('file')) {
                    if (confirm("Are you sure want to replace existing document?")) {
                        
                    } else {
                        return false;
                    }
                } 
                form = jqForm;
                jqForm.find('.progress-indicator').removeClass('d-none');
            },
            uploadProgress: function(event, position, total, percentComplete) {
                $("input[type='file']").attr('disabled', 'disabled');

                var percentVal = percentComplete + '%';
                form.find('.progress-indicator').find('.progress-bar').css('width', percentVal);
                form.find('.progress-indicator').find('.progress-bar').html(percentVal);
            },
            success: function(data) {
                setAlert(data);
                window.lastScrollPosition = window.scrollY;
                $(".icons-tab-steps").steps('previous');
                $(".icons-tab-steps").steps('next');
            },
            error: function(data) {
                toast("error", "Something went wrong.", "Error");
            },
            complete: function(responseText, statusText, xhr) {
                form.find('.progress-indicator').addClass('d-none');
                $("input[type='file']").removeAttr('disabled');
            }
        });

        editOtherDocumentScript();
    }

    function manageOtherDocumentScript() {
        validateForm($(".add-document-form"), {
            "rules" : {},
            "messages": {}
        });
        submitForm($('.add-document-form'), {
            beforeSubmit: function(formData, jqForm, options) {
                form = jqForm;
                jqForm.find('.progress-indicator').removeClass('d-none');
            },
            uploadProgress: function(event, position, total, percentComplete) {
                $("input[type='file']").attr('disabled', 'disabled');

                var percentVal = percentComplete + '%';
                form.find('.progress-indicator').find('.progress-bar').css('width', percentVal);
                form.find('.progress-indicator').find('.progress-bar').html(percentVal);
            },
            success: function(data) {
                setAlert(data);
                window.lastScrollPosition = window.scrollY;
                $(".icons-tab-steps").steps('previous');
                $(".icons-tab-steps").steps('next');
            },
            error: function(data) {
                toast("error", "Something went wrong.", "Error");
            },
            complete: function(responseText, statusText, xhr) {
                form.find('.progress-indicator').addClass('d-none');
                $("input[type='file']").removeAttr('disabled');
            }
        });
    }

    function editOtherDocumentScript() {
        $(".edit-document-form").each(function() {
            validateForm($(this), {
                "rules" : {},
                "messages": {}
            });
            var form1;
            submitForm($(this), {
                beforeSubmit: function(formData, jqForm, options) {
                    form1 = jqForm;
                    jqForm.find('.progress-indicator').removeClass('d-none');
                },
                uploadProgress: function(event, position, total, percentComplete) {
                    $("input[type='file']").attr('disabled', 'disabled');

                    var percentVal = percentComplete + '%';
                    form1.find('.progress-indicator').find('.progress-bar').css('width', percentVal);
                    form1.find('.progress-indicator').find('.progress-bar').html(percentVal);
                },
                success: function(data) {
                    setAlert(data);
                    window.lastScrollPosition = window.scrollY;
                    $(".icons-tab-steps").steps('previous');
                    $(".icons-tab-steps").steps('next');
                },
                error: function(data) {
                    toast("error", "Something went wrong.", "Error");
                },
                complete: function(responseText, statusText, xhr) {
                    form1.find('.progress-indicator').addClass('d-none');
                    $("input[type='file']").removeAttr('disabled');
                }
            });
        });
        
    }
</script>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/student/profile/steps/upload_documents.blade.php ENDPATH**/ ?>