<div class="row">
    <div class="col">
        <?php echo $__env->make('dashboard.inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<form id="course-create-form" action="<?php echo e(route('admin.campus.update', $campus->id)); ?>" method="post">
    <div class="row">
        <div class="col-md-6 col-12">
            <h4>Campus Information</h4><hr/>
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('dashboard.common.fields.text', [
            'label_name' => 'Campus',
            'id' => 'name',
            'name' => 'name',
            'placeholder' => 'Enter Campus Name',
            'input_attribute' => [
            'type' => 'text',
            'value' => old('name', $campus->name),
            ],
            'classes' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <div class="form-group">
                <label for="university">University</label>
                <select class='form-control university' name="university">
                    <option value="">--Select--</option>
                    <?php $__currentLoopData = config('universities'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $univ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($univ->id == old('university', $campus->university->id) ? 'selected' : ''); ?>

                            value="<?php echo e($univ->id); ?>"><?php echo e($univ->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php echo $__env->make('dashboard.common.fields.text', [
            'label_name' => 'Website',
            'id' => 'website',
            'name' => 'website',
            'placeholder' => 'Enter Website',
            'input_attribute' => [
            'type' => 'url',
            'value' => old('website',$campus->website),
            ],
            'classes' => '',
            'help_text' => 'e.g http(s)://example.com'
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <div id="program-picture">
                <?php echo $__env->make('dashboard.common.fields.text', [
                'label_name' => 'Logo',
                'id' => 'logo',
                'name' => 'logo',
                'placeholder' => 'Enter Program Duration',
                'input_attribute' => [
                'type' => 'file',
                'value' => old('logo'),
                ],
                'classes' => '',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                
            </div>



            <div class="form-group">
                <?php if($campus->logo == ''): ?>
                    <p class="no-image">Image Not Available</p>
                <?php else: ?>

                    <img class="img-fluid" src="<?php echo e(asset('uploads/program_logo/' . $campus->logo)); ?>" id="program-logo" width="200"
                         style="cursor: pointer">
                    <div class="text-muted">Click/Tap to change logo</div>
                <?php endif; ?>
            </div>


        </div>
        <div class="col-md-6 col-12">
            <h4>Campus Address Details</h4>
            <hr>
            <?php echo $__env->make('dashboard.common.fields.text', [
            'label_name' => 'Address',
            'id' => 'address',
            'name' => 'address',
            'placeholder' => 'Enter Campus Address',
            'input_attribute' => [
            'type' => 'text',
            'value' => old('address', $campus->address->address ?? ""),
            ],
            'classes' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="form-group">
                <label for="country">Country</label>
                <select class='form-control country_id <?php $__errorArgs = [' country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>' name="country"
                    id="country" data-live-search="true">
                    <option value="">--Select Country--</option>
                    <?php $__currentLoopData = config('countries'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($country->id == old('country', $campus->address->country_id ?? "") ? 'selected' : ''); ?>

                            value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="state">State</label>
                <select class='form-control select  <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>' name="state" id="state"
                    data-live-search="true">
                    <option value="">--Select State--</option>
                    <?php $__currentLoopData = config('states'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($state->id == old('state', $campus->address->state_id ?? "") ? 'selected' : ''); ?>

                            value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="city">City</label>
                <select class='form-control select <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e(errCls()); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>' name="city" id="city"
                    data-live-search="true">
                    <option value="">--Select City--</option>
                    <option value="new-city">Add New City</option>
                    <?php $__currentLoopData = config('cities'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e($city->id == old('city', $campus->address->city_id ?? "") ? 'selected' : ''); ?>

                            value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="text" name="new_city" class="form-control mt-2 d-none" placeholder="Enter new City Name"
                    id="new-city">
                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="form-group">
                <button type="submit" id="submit-btn" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</form>
<?php if($campus->campusProgram->count() > 0): ?>
    <div class="col-12">
        <p><?php echo e(config('setting.delete_notice')); ?></p>
    </div>
<?php else: ?>
    <div class="form-group delete" style="margin-top:1%">
       <form  id="delete-form" method="POST" action="<?php echo e(route('admin.campus.destroy', $campus->id)); ?>" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
          <button type="submit" id="submit-btn-delete" class="btn btn-danger">Delete</button>
         </form>
      </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/campus/edit.blade.php ENDPATH**/ ?>