<?php if(config('app.env') == 'production'): ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-0WSL3QMBW7"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-0WSL3QMBW7');

    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/inc/gtag.blade.php ENDPATH**/ ?>