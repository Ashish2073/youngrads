<?php $__env->startSection('title', 'Campus Program'); ?>

<?php $__env->startSection('breadcumb-right'); ?>
    <a href="<?php echo e(route('admin.campus-program.create')); ?>" class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle">
        <i class="feather icon-plus"></i>
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section id="basic-datatable">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        
                    </div>
                    <div class="card-content">
                        <div class="card-body card-dashboard">

                            <div class="table-responsive">
                                <table id="table" class="table table-hover w-100 zero-configuration">
                                    <thead>
                                        <tr>
                                        <tr>
                                            <th>University</th>
                                            <th>Campus</th>
                                            <th>Program</th>
                                            <th>Action</th>
                                        </tr>
                                        </tr>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <script>
        $(document).ready(function() {
            <?php if(session('success')): ?>
                toast('success', "<?php echo e(session('success')); ?>")
            <?php endif; ?>

            <?php if(session('error')): ?>
                toast('error', "<?php echo e(session('error')); ?>")
            <?php endif; ?>
            // Datatable
            dataTable = $("#table").DataTable({
                "processing": true,
                "serverSide": true,
                "bInfo": true,
                "pageLength": 100,
                "fixedHeader": true,
                ajax: {
                    url: "<?php echo e(route('admin.campus-programs')); ?>",
                    data: function(d) {}
                },
                columns: [{
                        name: 'universities.name',
                        data: 'univ_name'
                    },
                    {
                        data: 'campus',
                        name: 'campus'
                    },
                    {
                        data: 'program',
                        name: 'program'
                    },
                    {
                        data: 'action'
                    }

                ],

                'createdRow': function(row, data, dataIndex) {
                    // $(row).addClass('action-row');
                    // let id = data['id'];
                    // let editUrl = route('admin.user.edit', id).url();
                    // $(row).attr('data-url', editUrl);
                    // $(row).attr('data-target', "#dynamic-modal");
                    // $(row).attr('data-toggle', "modal");
                },
                initComplete: function(res, json) {

                }
            });




        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/campus_program/index.blade.php ENDPATH**/ ?>