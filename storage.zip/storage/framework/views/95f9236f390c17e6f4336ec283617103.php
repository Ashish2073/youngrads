<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Youngrads')); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
        integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" type="text/css" media="screen" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" />
    <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="" sizes="32x32">

    

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/vendors.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/ui/prism.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/plugins/forms/validation/form-validation.css')); ?>">
    <?php echo $__env->yieldContent('vendor-style'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-extended.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/colors.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/components.css')); ?>">
    
    
    
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <?php
        $configData = Helper::applClasses();
    ?>

    

    
    
    <?php if($configData['mainLayoutType'] === 'horizontal'): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/core/menu/menu-types/horizontal-menu.css')); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/core/menu/menu-types/vertical-menu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/core/colors/palette-gradient.css')); ?>">
    
    <?php echo $__env->yieldContent('page-style'); ?>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/forms/select/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/tables/datatable/datatables.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/custom-laravel.css')); ?>">
    
    <?php if($configData['direction'] === 'rtl' && isset($configData['direction'])): ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/custom-rtl.css')); ?>">
    <?php endif; ?>
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">

    <style>
        table.data-list-view.dataTable tbody tr,
        table.data-thumb-view.dataTable tbody tr {
            cursor: unset !important;
        }
    </style>

    

    <?php echo $__env->make('inc.gtag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <header class="header">
        <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    

    <script src="<?php echo e(asset('vendors/js/vendors.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/ui/prism.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(asset('js/scripts/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/select_ajax.js')); ?>"></script>

    

    
    <script src="<?php echo e(asset('vendors/js/vendors.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/ui/prism.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('vendor-script'); ?>
    
    <script src="<?php echo e(asset('js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('js/core/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/components.js')); ?>"></script>
    <?php if($configData['blankPage'] == false): ?>
        <script src="<?php echo e(asset('js/scripts/customizer.js')); ?>"></script>
        <script src="<?php echo e(asset('js/scripts/footer.js')); ?>"></script>
    <?php endif; ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/additional-methods.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/buttons.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/tables/datatable/datatables.bootstrap4.min.js')); ?>"></script>
    <script>
        toastr.options = {
            "closeButton": false,
            "debug": false,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };
        $(".has-sub").each(function() {
            let sub = $(this).find('ul');
            if (sub.children().length == 0) {
                $(this).remove();
            }
        });
    </script>
    <script src="<?php echo e(asset('js/scripts/jquery.form.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/main.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/js/forms/select/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scripts/select_ajax.js')); ?>"></script>
    <script>
        $('#view-profile').on('click', function() {
            id = "<?php echo e(Auth::id()); ?>";


            var url = `<?php echo e(url('student/${id}/viewprofile')); ?>`;

            console.log("hello");
            $('#apply-model').modal('show');
            $('.apply-title').html('View Profile');
            $(".dynamic-apply").html("Loading...");
            getContent({
                "url": url,
                success: function(data) {
                    $('#apply-model').find('.modal-dialog').addClass('modal-lg');
                    $(".dynamic-apply").html(data);
                }
            });
        });
    </script>

    <script>
        jQuery(document).ready(function() {
            jQuery(".navbar button.navbar-toggler").click(function() {
                jQuery(".navbar button.navbar-toggler").toggleClass("active-mobile-menu");
                jQuery(".header .navbar").toggleClass("open-nav");
                jQuery('#navbarSupportedContent').slideToggle();
            });
        });
    </script>


    
    <?php echo $__env->yieldContent('page-script'); ?>

    <?php echo $__env->yieldContent('foot_script'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/layouts/beta_layout.blade.php ENDPATH**/ ?>