
<form action="<?php echo e(route('email-change', $user->id)); ?>" method="post" id="change-email">
  <?php echo csrf_field(); ?>
  <?php echo $__env->make('dashboard.common.fields.text', [
    'label_name' => 'Email Address',
    'id' => 'email',
    'name' => 'email',
    'placeholder' => 'Enter Email Address',
    'input_attribute' => [
        'type' => 'email',
        'value' => old('email'),
        'required' => 'required'
    ],
    'classes' => '',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('dashboard.common.fields.text', [
    'label_name' => 'Confirm Email Address',
    'id' => 'confirm-email',
    'name' => 'confirm_email',
    'placeholder' => 'Enter Confirm Email Address',
    'input_attribute' => [
        'type' => 'email',
        'value' => old('confirm_email'),
        'required' => 'required'

    ],
    'classes' => '',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($user->new_email != Null): ?>
  <div class="alert alert-warning alert-dismissible mb-2" role="alert">
    <button type="button" class="close d-none" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">×</span>
    </button>
    <p class="mb-0">
      Your email verification is pending for <u><?php echo $user->new_email; ?></u>
    </p>
  </div>
<?php endif; ?>
<button type="submit" class="btn btn-primary" id="change-email-btn">Change Email</button>
</form>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/student/change_email.blade.php ENDPATH**/ ?>