<footer class="footer">
    <div class="container">
        <div class="row w-100">
            <div class="col-12 col-md-6 px-0 text-left">
                <p>Copyright ©<?php echo e(date('Y')); ?> <a href="#"><?php echo e(config('app.name')); ?></a></p>
            </div>
            <div class="col-12 col-md-6 px-0 text-md-right text-left">
                <a class="ml-0" href="<?php echo e(route('terms')); ?>">Terms of use</a>
                <a  href="<?php echo e(route('privacy_policy')); ?>">Privacy Policy</a>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/inc/footer.blade.php ENDPATH**/ ?>