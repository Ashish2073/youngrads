<?php if($errors->any() || session()->has('error')): ?>
    <div class="alert alert-danger alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php if($errors->has('form_error')): ?>
            <?php echo e($errors->first('form_error')); ?>

        <?php else: ?>
            <?php echo e(session()->get('error')); ?>

        <?php endif; ?>
    </div>
<?php endif; ?>

<?php if(session()->has('success')): ?>
    <div class="alert alert-success alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(isset($success)): ?>
    <div class="alert alert-success alert-dismissible">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>

        <?php echo e($success); ?>



    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/dashboard/inc/message.blade.php ENDPATH**/ ?>