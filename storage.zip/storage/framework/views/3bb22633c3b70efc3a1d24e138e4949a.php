
<ul class="menu-content">
    <?php if(isset($menu)): ?>
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $submenuTranslation = "";
                if(isset($menu['i18n'])){
                    $submenuTranslation = $menu['i18n'];
                }
            ?>
            <?php if( 
                !isset($submenu['permission']) || 
                empty($submenu['permission']) || 
                (
                    isset($submenu['permission']) && 
                    auth(config('auth.guard.admin'))->user()->can($submenu['permission'])
                ) 
            ): ?>
                <li class=" <?php echo e(request()->route()->getName() == $submenu['route'] ? "active" : ""); ?> ">
                    <a href="<?php echo e(isset($submenu['route']) ? route($submenu['route']) : ""); ?>">
                        <i class="<?php echo e(isset($submenu['icon_class']) ? $submenu['icon_class'] : ""); ?>"></i>
                        
                        <span class="menu-title" data-i18n="<?php echo e($submenuTranslation); ?>"><?php echo e(__($submenu['menu_name'])); ?></span>
                    </a>
                    <?php if(isset($submenu['sub_menu'])): ?>
                        <?php echo $__env->make('panels/submenu', ['menu' => $submenu['sub_menu']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</ul>
<?php /**PATH C:\xampp\htdocs\youngardsnew\resources\views/panels/submenu.blade.php ENDPATH**/ ?>