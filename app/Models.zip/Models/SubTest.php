<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubTest extends Model
{
  protected $table = "user_sub_test_score";
  protected $guarded = [];
}
