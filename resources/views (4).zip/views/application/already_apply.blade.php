<div class="row">
  <div class="col-md-12">
    <p class="text-center">You have already applied for this program or You have applied all intakes for this program.</p>
  </div>
</div>
