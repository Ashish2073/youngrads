<div class="row">
    <div class="col-md-12">
        <p><strong>Name:</strong> {{ $contact->name }}</p>
        <p><strong>Email:</strong> {{ $contact->email }}</p>
        <p><strong>Message:</strong> {{ $contact->message }}</p>
    </div>
</div>
