@extends('layouts.app')

@section('content')
    <div class="container py-5">
        {!! $page->content !!}
    </div>
@endsection
