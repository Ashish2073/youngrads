{{-- <div class="card">
    <div class="card-content">
        <div class="card-body">
            <p>
                {{ config('setting.application.status')[$record->status] }}
                <span>{{ date("d M Y h:i A", strtotime($record->created_at)) }}</span>
            </p>
        </div>
    </div>
</div> --}}

