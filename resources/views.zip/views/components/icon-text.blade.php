<div class="d-flex">
    <div class="">
        <span class="{{ $icon }} text-primary pr-1" ></span>
    </div>
    <div class="">
        <h5>{{ $heading }}</h5>
        <span style="white-space: normal;">
            {!! $slot !!}
        </span>
    </div>
</div>